﻿using System;

namespace Fundamentals
{
    class Program
    {
        static void Main(string[] args)
        {
        //loop that prints values from 1-255
        for (int i = 1; i <= 255; i++)
        {
            Console.WriteLine(i);
        }    
            
        //loop that prints values from 1-100 that are divisible by 3 or 5 but not both
        //print Fizz for multiples of 3, Buzz for multiples of 5, FizzBuzz for numbers divisible by both 3 and 5
        for (int n = 1; n <= 100; n++)
        {
            if (n % 15 == 0)
            {
                Console.WriteLine("FizzBuzz");
            }
            
            else if (n % 3 == 0)
            {
                Console.WriteLine("Fizz");
            }

            else if (n % 5 == 0)
            {
                Console.WriteLine("Buzz");
            }

            else
            {
                Console.WriteLine(n);
            }
        }

        }
        
    }
}
